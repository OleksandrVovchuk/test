#include <stdio.h.>
#include <stdlib.h.>

int main()
{
    int n;
    scanf("%d",&n);

    for (int i=1; i <= n; i++)
    {
        for (int j=1; j <= n + 1; j++)
        {
            if (n + 1 - (i + 1) < j)
            {
                printf("#");
            }
            else
            {
                printf(" ");
            }
        }
        printf("\n");
    }
    return 0;
}
