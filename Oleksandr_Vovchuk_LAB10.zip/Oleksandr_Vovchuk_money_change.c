#include <stdio.h.>
#include <stdlib.h.>
#include <math.h>

int main()
{
    float sum , a[] = {50, 25, 10, 1};
    int k = 0;
    
    scanf("%f",&sum);
    sum= sum * 100;
    for ( int i = 0; i < 4; i++ )
    {
        k = k + floor(sum / a[i]);
        sum = sum - floor(sum / a[i])*a[i];
    }
    printf("%d",k);
    return 0;
}
