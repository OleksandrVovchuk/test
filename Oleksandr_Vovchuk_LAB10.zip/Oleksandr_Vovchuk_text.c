#include <stdio.h>
#include <math.h>
#include <string.h>

int main()
{
    char str_1[82];
    char str_2[82];
    int i, j, k=0;

    printf("Enter line: ");
    if(fgets(str_1, sizeof(str_1), stdin) == NULL || *str_1 == '\n')
        return 1;

    for(i = j = 0; str_1[i] != '\0'; i++)
        if(str_1[i] != ' ')
            str_2[j++] = str_1[i];
    str_2[j] = '\0';

    int len = strlen(str_2);
    int L = (int)sqrt(strlen(str_2));
    int rows = L, colums = L;
    if(rows*colums<strlen(str_2)-1)
    {
        colums++;
    }
    if(rows*colums<strlen(str_2)-1)
    {
        rows++;
    }


    char table[rows][colums];
    for(int j=0; j<rows; j++)
    {
        printf("\n");
        for(int i =0; i <colums; i++)
        {
            table[j][i]=str_2[k];
            if(k==strlen(str_2))
            {
                break;
            }
            printf("%c", str_2[k]);
            k++;

        }
    }
    return 0;
}
